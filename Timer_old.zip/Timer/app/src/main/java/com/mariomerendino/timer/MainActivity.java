package com.mariomerendino.timer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.*;
import android.widget.SeekBar;
import android.text.*;
import android.widget.SeekBar.OnSeekBarChangeListener;


public class MainActivity extends AppCompatActivity {
    TextView MinTextView;
    TextView HrTextView;

    EditText MinEditText;
    EditText HrEditText;

    int inputHr = 24;
    int inputMin = 30;

    SeekBar MinSeekBar;
    SeekBar HrSeekBar;
    SeekBar PSeekBar;

    int seekBarMin = 30;
    int seekBarHr = 12;
    int percent = 50;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //TextViews
        MinTextView = (TextView) findViewById(R.id.MinuteTextView);
        HrTextView = (TextView) findViewById(R.id.HourTextView);

        //EditTexts
        MinEditText = (EditText) findViewById(R.id.minutesEdit);
        HrEditText = (EditText) findViewById(R.id.hoursEdit);
        //TextChangedListeners For Edit Texts
        MinEditText.addTextChangedListener(minEditTextWatcher);
        HrEditText.addTextChangedListener(hrEditTextWatcher);

        //Seekbar
        MinSeekBar = (SeekBar)findViewById(R.id.MinuteSeekBar);
        HrSeekBar = (SeekBar)findViewById(R.id.HourSeekBar);
        PSeekBar = (SeekBar)findViewById(R.id.percentBar);
        //SeekbarListeners
        MinSeekBar.setOnSeekBarChangeListener(seekBarListener);
        HrSeekBar.setOnSeekBarChangeListener(seekBarListener);
        PSeekBar.setOnSeekBarChangeListener(seekBarListener);




    }
    // listener object for the SeekBar's progress changed events
    private final OnSeekBarChangeListener seekBarListener =
            new OnSeekBarChangeListener() {
                // update percent, then call calculate
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress,
                                              boolean fromUser) {
                    //FIX
                    if(seekBar.getId() == (R.id.MinuteSeekBar) ){
                        seekBarMin = progress;
                        MinTextView.setText(Integer.toString(seekBarMin));
                    }
                    if(seekBar.getId() == (R.id.HourSeekBar) ) {
                        seekBarHr = progress;
                        HrTextView.setText(Integer.toString(seekBarHr));
                    }
                    if(seekBar.getId() == (R.id.percentBar) ) {
                        PSeekBar.setProgress(percent);
                    }
                    calculate(); // calculate and display tip and total
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) { }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) { }
            };

    public void calculate(){

    }
    private final TextWatcher minEditTextWatcher = new TextWatcher() {

        // called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start,
                                  int before, int count) {

            try {
                inputMin = Integer.valueOf(s.toString());

            }
            catch (NumberFormatException e) {
                MinEditText.setText("");
            }

            calculate(); // update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s) { }

        @Override
        public void beforeTextChanged(
                CharSequence s, int start, int count, int after) { }
    };
    private final TextWatcher hrEditTextWatcher = new TextWatcher() {

        // called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start,
                                  int before, int count) {

            try {
                inputHr = Integer.valueOf(s.toString());

            }
            catch (NumberFormatException e) {
                HrEditText.setText("");
            }

            calculate(); // update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s) { }

        @Override
        public void beforeTextChanged(
                CharSequence s, int start, int count, int after) { }
    };
}
